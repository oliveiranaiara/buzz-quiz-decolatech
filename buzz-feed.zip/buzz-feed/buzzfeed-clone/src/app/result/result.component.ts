
import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';

@Component({
  selector: 'app-result',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="container">
      <h2>Seu resultado:</h2>
      <p>Você seria: {{ result }}</p>
      <button (click)="restart()">Recomeçar</button>
    </div>
  `,
  styles: [`
    .container {
      padding: 20px;
      text-align: center;
    }
    button {
      margin: 10px;
      padding: 10px 20px;
    }
  `]
})
export class ResultComponent implements OnInit {
  result: string = '';

  constructor(private router: Router) {
    const navigation = this.router.getCurrentNavigation();
    this.result = navigation?.extras?.state?.['result'] || 'Resultado não encontrado';
  }

  ngOnInit(): void {}

  restart(): void {
    this.router.navigate(['/']);
  }
}
